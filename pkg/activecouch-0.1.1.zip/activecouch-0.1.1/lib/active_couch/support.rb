require 'active_couch/support/inflector'
require 'active_couch/support/extensions'